import xbmc,xbmcaddon,xbmcgui,xbmcplugin,os,sys,xbmcvfs,shutil,urllib2,urllib,re,extract,downloader,time,plugintools,glob
from addon import Addon
from net import Net
USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON_ID = xbmc.getInfoLabel('Container.PluginName')
ADDON_NAME = xbmcaddon.Addon(ADDON_ID).getAddonInfo('name')
ADDON_PATH = os.path.join(xbmc.translatePath('special://home'), ADDON_ID) + '/'
ADDON = xbmcaddon.Addon(id=ADDON_ID)
VERSION = xbmcaddon.Addon(ADDON_ID).getAddonInfo('version')
dialog = xbmcgui.Dialog()
net = Net()
U = ADDON.getSetting('User')
BASEURL = "http://myiptvbox.000webhostapp.com"
MENUURL = BASEURL+"/files/"
OTAURL = MENUURL+'ota.xml'
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID, 'icon.jpg'))
ART = BASEURL+'/images/'
OTAVERSION = urllib2.urlopen(MENUURL+"wizver.txt").read(4) # read only 4 chars
DBPATH = xbmc.translatePath('special://database')
TNPATH = xbmc.translatePath('special://thumbnails');
EXCLUDES = [ADDON_ID,'script.module.addon.common']

def INDEX():
    addDir('UPDATES/INSTALLS',BASEURL,10,ART+'ota.png',FANART,'')
    addDir('MAINTENANCE',BASEURL,30,ART+'maintenance.png',FANART,'')
    addDir('READ ME!',BASEURL,11,ART+'readme.png',FANART,'')

def OTAMENU():
    link = OPEN_URL(OTAURL).replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?um="(.+?)".+?mg="(.+?)".+?rt="(.+?)".+?xt="(.+?)"').findall(link)
    for name,url,num,img,art,txt in match:
        addDir(name,url,num,img,art,txt)

def OTHERBUILDS():
    link = OPEN_URL(MENUURL+'others.xml').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?um="(.+?)".+?mg="(.+?)".+?rt="(.+?)".+?xt="(.+?)"').findall(link)
    for name,url,num,img,art,txt in match:
        addDir(name,url,num,img,art,txt)

def LOCALMENU():
    addDir('SD CARD','url',21,ART+'sd.png',FANART,'Requires zip file in the root of the SD Card')
    addDir('EXT USB','url',22,ART+'usb.png',FANART,'Requires zip file in the root of the USB stick/drive')
    addDir('DOWNLOAD FOLDER','url',23,ART+'dl.png',FANART,'Requires zip file in the Download folder on your droid box')

def WEBMENU(url):
    link = OPEN_URL(url).replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?um="(.+?)".+?mg="(.+?)".+?rt="(.+?)".+?xt="(.+?)"').findall(link)
    for name,url,num,img,art,txt in match:
        addDir(name,url,num,img,art,txt)        

def USBMENU():
    addDir('rebuild.zip from EXT USB','/storage/external_storage/sda1/rebuild.zip',37,ART+'rebuild.png',FANART,'Requires a file named rebuild.zip in the root of the USB stick/drive')
    addDir('patch.zip from EXT USB','/storage/external_storage/sda1/patch.zip',38,ART+'patch.png',FANART,'Requires a file named patch.zip in the root of the USB stick/drive')

def SDMENU():
    addDir('rebuild.zip from SD CARD','/storage/external_storage/sdcard1/rebuild.zip',37,ART+'rebuild.png',FANART,'Requires a file named rebuild.zip in the root of the SD Card')
    addDir('patch.zip from SD CARD','/storage/external_storage/sdcard1/patch.zip',38,ART+'patch.png',FANART,'Requires a file named patch.zip in the root of the SD Card')

def DLMENU():
    addDir('rebuild.zip from Download folder','/sdcard/Download/rebuild.zip',37,ART+'rebuild.png',FANART,'Requires a file named rebuild.zip in the Download folder on your droid box')
    addDir('patch.zip from Download folder','/sdcard/Download/patch.zip',38,ART+'patch.png',FANART,'Requires a file named patch.zip in the Download folder on your droid box')

def MAINTENANCE():
    addDir('DELETE CACHE','url',31,ART+'deletecache.png',FANART,'')
    addDir('FRESH START','url',32,ART+'freshstart.png',FANART,'')
    addDir('DELETE PACKAGES','url',33,ART+'deletepackages.png',FANART,'')
    addDir('REBOOT','url',40,ART+'blank.png',FANART,'')
    addDir('TEST','http://myiptvbox.000webhostapp.com/apk',41,ART+'blank.png',FANART,'')
    addDir('BACKUP','url',35,ART+'blank.png',FANART,'')
    addDir('RESTORE','url',20,ART+'blank.png',FANART,'')

####### POPUP TEXT BOXES ########

def TextBoxes(heading,announce):
  class TextBox():
    WINDOW=10147
    CONTROL_LABEL=1
    CONTROL_TEXTBOX=5
    def __init__(self,*args,**kwargs):
      xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
      self.win=xbmcgui.Window(self.WINDOW) # get window
      xbmc.sleep(500) # give window time to initialize
      self.setControls()
    def setControls(self):
      self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
      try: f=open(announce); text=f.read()
      except: text=announce
      self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
      return
  TextBox()

def readme():
    TextBoxes(ADDON_NAME + ' v' + VERSION +'      Latest Version v' + OTAVERSION, OPEN_URL(MENUURL + 'disclaimer.txt'))
    return

def rebuild():
    TextBoxes('The 5p0ng3b0b wizard ' + VERSION, '[COLOR=orange]Note: If you are performing a rebuild, please ensure you have completed a fresh start in the maintenance section before commencing any installations[/COLOR]')

def runscript():
    SCRIPT = 'adb shell sh ' + ADDON_PATH + 'test.sh'
    try: os.system(SCRIPT)
    except: pass

####BUILD INSTALL################

def DLWIZARD(name,url,description):
    path = DLFOLDER() 
#    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("The 5p0ng3b0b wizard","Downloading ",'', 'Please Wait')
    lib=os.path.join(path, name)
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    dialog.ok("FINISHED", "Download path " + DLFOLDER())
    killkodi()

def OTAWIZARD(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("Progress","Downloading Build")
    lib=os.path.join(path, name)
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0, "Extracting Zip")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    dialog = xbmcgui.Dialog()
#    dialog.ok("SUCCESS!", "NOW POWER OFF YOUR DEVICE AND REBOOT. DO NOT CLICK OK!")
    dialog.ok("SUCCESS!", "NOW KODI WILL EXIT TO FINALISE SETTINGS")
    killkodi()

def USBWIZARD(name,path,description):
    lib=os.path.join(path, name)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0,"", "Extracting Zip Please Wait")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    dialog = xbmcgui.Dialog()
#    dialog.ok("SUCCESS!", "NOW POWER OFF YOUR DEVICE AND REBOOT. DO NOT CLICK OK!")
    dialog.ok("SUCCESS!", "NOW KODI WILL EXIT TO FINALISE SETTINGS")

    killkodi()

def BACKUP(name,path):  
    if zip == '':
        dialog.ok('USB BACKUP/RESTORE','You have not set your ZIP Folder.\nPlease update the addon settings and try again.','','')
        ADDON.openSettings(sys.argv[0])
    to_backup = xbmc.translatePath(os.path.join('special://','home'))
    backup_zip = xbmc.translatePath(os.path.join(path,name))
    DeletePackages(url)    
    import zipfile
    dp = xbmcgui.DialogProgress()    
    dp.create("KODI SETUP CLONER","Creating zip file",'', 'Please Wait')
    zipobj = zipfile.ZipFile(backup_zip , 'w', zipfile.ZIP_DEFLATED)
    rootlen = len(to_backup)
    for_progress = []
    ITEM =[]
    for base, dirs, files in os.walk(to_backup):
        for file in files:
            ITEM.append(file)
    N_ITEM =len(ITEM)
    for base, dirs, files in os.walk(to_backup):
        for file in files:
            for_progress.append(file) 
            progress = len(for_progress) / float(N_ITEM) * 100  
            dp.update(int(progress),"Backing Up",'[COLOR yellow]%s[/COLOR]'%file, 'Please Wait')
            fn = os.path.join(base, file)
            if not 'temp' in dirs:
                if not ADDON_ID in dirs:
                   import time
                   CNT= '01/01/1980'
                   FILE_DATE=time.strftime('%d/%m/%Y', time.gmtime(os.path.getmtime(fn)))
                   if FILE_DATE > CNT:
                       zipobj.write(fn, fn[rootlen:])  
    zipobj.close()
    dp.close()
    dialog.ok("5p0ng3b0b wizard", "You Are Now Backed Up", '','')

###DELETE PACKAGES##############

def DeletePackages(url):
    print '############################################################       DELETING PACKAGES             ###############################################################'
    packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
    try:    
        for root, dirs, files in os.walk(packages_cache_path):
            file_count = 0
            file_count += len(files)
# Count files and give option to delete
            if file_count > 0:    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Package Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                            
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                    dialog = xbmcgui.Dialog()
                    dialog.ok("The 5p0ng3b0b wizard", "Packages Successfuly Removed", "[COLOR yellow]Brought To You By The 5p0ng3b0b wizard[/COLOR]")
    except: 
        dialog = xbmcgui.Dialog()
        dialog.ok("The 5p0ng3b0b wizard", "Sorry we were not able to remove Package Files", "[COLOR yellow]Brought To You By The 5p0ng3b0b wizard[/COLOR]")
    
###DELETE CACHE###

def deletecachefiles(url):
    print '############################################################       DELETING STANDARD CACHE             ###############################################################'
    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
    if os.path.exists(xbmc_cache_path)==True:    
        for root, dirs, files in os.walk(xbmc_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
                
                    for f in files:
                        try:
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
                        
            else:
                pass
    if xbmc.getCondVisibility('system.platform.ATV2'):
        atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        
        for root, dirs, files in os.walk(atv2_cache_a):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
        atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        
        for root, dirs, files in os.walk(atv2_cache_b):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
              # Set path to Cydia Archives cache files
                             

    # Set path to What th Furk cache files
    wtf_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk/cache'), '')
    if os.path.exists(wtf_cache_path)==True:    
        for root, dirs, files in os.walk(wtf_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
                    
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to 4oD cache files
    channel4_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.4od/cache'), '')
    if os.path.exists(channel4_cache_path)==True:    
        for root, dirs, files in os.walk(channel4_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
                    
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to BBC iPlayer cache files
    iplayer_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache'), '')
    if os.path.exists(iplayer_cache_path)==True:    
        for root, dirs, files in os.walk(iplayer_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
                    
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                
                # Set path to Simple Downloader cache files
    downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
    if os.path.exists(downloader_cache_path)==True:    
        for root, dirs, files in os.walk(downloader_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
                    
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
						
            else:
                pass

                # Set path to ITV cache files
    itv_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.itv/Images'), '')
    if os.path.exists(itv_cache_path)==True:    
        for root, dirs, files in os.walk(itv_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
                    
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
				
                # Set path to temp cache files
    temp_cache_path = os.path.join(xbmc.translatePath('special://home/temp'), '')
    if os.path.exists(temp_cache_path)==True:    
        for root, dirs, files in os.walk(temp_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
				

    dialog = xbmcgui.Dialog()
    dialog.ok("The 5p0ng3b0b wizard", " All Cache Files Removed", "[COLOR yellow]Brought To You By The 5p0ng3b0b wizard[/COLOR]")
 
        
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    
def OPEN_LNK(url):
    cmmnd = 'adb shell am start -n com.android.chrome/com.google.android.apps.chrome.Main -d '
    cmmnd = cmmnd+url+'; sleep 10'
    try: os.system(cmmnd)
    except: pass
    # cmmnd = 'if [ $(pm list packages | grep -e \'com.android.chrome\') ]; then am start -n com.android.chrome/com.google.android.apps.chrome.Main -d ' + url + '; sleep 10; input keyevent 4; return; fi; if [ $(pm list packages | grep -e \'com.android.browser\') ]; then am start -a android.intent.action.VIEW -n com.android.browser/.BrowserActivity -d ' + url + ' && sleep 5; input keyevent 4; return; fi; am start -a android.intent.action.VIEW -d '+ url + '&& sleep 10; input keyevent 4'
    # cmmnd = 'am start -n com.android.chrome/com.google.android.apps.chrome.Main -d ' + url + '; sleep 10; input keyevent 4'


###############################################################
###FORCE CLOSE KODI - ANDROID ONLY WORKS IF ROOTED#############
###############################################################
def reboot():
    try: os.system('adb shell reboot')
    except: pass

def killkodi():
#    choice = xbmcgui.Dialog().yesno('Force Close Kodi', 'You are about to close Kodi', 'Would you like to continue?', nolabel='No, Cancel',yeslabel='Yes, Close')
#    if choice == 0:
#        return
#    elif choice == 1:
#        pass
    myplatform = platform()
    print "Platform: " + str(myplatform)
    if myplatform == 'osx': # OSX
        print "############   try osx force close  #################"
        try: os.system('killall -9 Kodi')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
    elif myplatform == 'linux': #Linux
        print "############   try linux force close  #################"
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
    elif myplatform == 'android': # Android  
        print "############   try android force close  #################"
        try: os.system('adb shell reboot')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass
        try: os.system('kilall -9 org.xbmc.kodi')
        except: pass
#        dialog.ok("[COLOR=yellow][B]TO COMPLETE UPDATE[/COLOR][/B]", "Press the HOME button on your remote and run the kill all app")
        dialog.ok("EXIT KODI FAILED!", "POWER OFF YOUR DEVICE NOW AND REBOOT. DO NOT CLICK OK!")

    elif myplatform == 'windows': # Windows
        print "############   try windows force close  #################"
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except: pass

        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.","Use task manager and NOT ALT F4")
    else: #ATV
        print "############   try atv force close  #################"
        try: os.system('killall AppleTV')
        except: pass
        print "############   try raspbmc force close  #################" #OSMC / Raspbmc
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit via the menu.","iOS detected.  Press and hold both the Sleep/Wake and Home button for at least 10 seconds, until you see the Apple logo.")

##########################
###DETERMINE PLATFORM#####
##########################
        
def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

def dlfolder():
    if xbmc.getCondVisibility('system.platform.android'):
        return '/sdcard/Download'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return '%userprofile%/downloads'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return '/sdcard/Download'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return '/sdcard/Download'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return '/sdcard/Download'

#############################################################################
####                             FRESH START                             ####
####THANK YOU TVADDONS FOR PROVIDING THE OPPORTUNITY TO DEBUG AND IMPROVE####
#############################################################################
def FRESHSTART(params):
    plugintools.log("freshstart.main_list "+repr(params)); yes_pressed=plugintools.message_yes_no(ADDON_NAME,"Do you wish to restore your","Kodi configuration to default settings?")
    if yes_pressed:
         wipeaddons()
    else: plugintools.message(ADDON_NAME,"Your settings","have not been changed"); plugintools.add_item(action="",title="Done",folder=False)

def wipeaddons():
        addonPath=xbmcaddon.Addon(id=ADDON_ID).getAddonInfo('path'); addonPath=xbmc.translatePath(addonPath); 
        xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
        try:
            for root, dirs, files in os.walk(xbmcPath,topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in files:
                    try: os.remove(os.path.join(root,name))
                    except:
                        if f not in ["Addons15.db","MyVideos75.db","Textures13.db","xbmc.log"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
                for name in dirs:
                    #dialog.ok("folder", name)
                    try:
                        #os.remove(os.path.join(root,name))
                        #shutil.rmtree(os.path.join(root,name))
                        os.system('rm -rf /sdcard/Android/data/org.xbmc.kodi/files/.kodi/addons/' + name)
                        os.system('rm -rf /sdcard/Android/data/org.xbmc.kodi/files/.kodi/userdata/' + name)
                    except:
                        if name not in ["Database","userdata",ADDON_ID]: failed=True
                        plugintools.log("Error removing "+root+" "+name)					
            if not failed: plugintools.log("freshstart.main_list All user files removed, you now have a clean install"); plugintools.message(ADDON_NAME,"The process is complete, you're now back to a fresh Kodi configuration with The 5p0ng3b0b wizard!","Click OK to exit Kodi in order for the changes to be applied.")
            else: plugintools.log("freshstart.main_list User files partially removed"); plugintools.message(ADDON_NAME,"The process is complete, you're now back to a fresh Kodi configuration with The 5p0ng3b0b wizard!","Click OK to exit Kodi in order for the changes to be applied.")
        except: plugintools.message(ADDON_NAME,"Problem found","Your settings has not been changed"); import traceback; plugintools.log(traceback.format_exc()); plugintools.log("freshstart.main_list NOT removed")

#        plugintools.add_item(action="",title="Now exit Kodi before continuing with the update wizard",folder=False)
        killkodi()

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==5 :
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(ADDON_NAME)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        

if mode==None or url==None or len(url)<1:
        INDEX()

# MENUS
elif mode==10:
        OTAMENU()       
elif mode==11:
       readme()
elif mode==12:
        OTHERBUILDS()
elif mode==13:
        WEBMENU(url)
elif mode==14:
        DLWIZARD(url)
# 20 USB MENUS
elif mode==20:
       LOCALMENU()
elif mode==21: #SD CARD
        SDMENU()
elif mode==22: #USB STICK
        USBMENU()
elif mode==23: #DOWNLOAD FOLDER
        DLMENU()

# 30 MAINTENANCE MENUS
elif mode==30:
        MAINTENANCE()
elif mode==31:
        deletecachefiles(url)
elif mode==32:        
	      FRESHSTART(params)
elif mode==33:
        DeletePackages(url)
elif mode==34:
        RepairAll()
elif mode==35:
        addonPath=xbmcaddon.Addon(id=ADDON_ID).getAddonInfo('path');
        BACKUP('backup.zip',"c:\\")
elif mode==36:
        OTAWIZARD('build.zip',url,description)
elif mode==37:
        OTAWIZARD('patch.zip',url,description)
elif mode==38:
        USBWIZARD('build.zip',url,description)
elif mode==39:
        USBWIZARD('patch.zip',url,description)
elif mode==40:
        reboot()
elif mode==41:
        OPEN_LNK(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
