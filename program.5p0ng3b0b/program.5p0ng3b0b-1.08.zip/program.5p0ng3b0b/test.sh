#!/system/bin/sh
echo 'it worked!' >> /sdcard/kodi/.mygica/addons/plugin.program.5p0ng3b0b/test.txt
am start -n com.android.chrome/com.google.android.apps.chrome.Main -d http://www.google.co.uk
